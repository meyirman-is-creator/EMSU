package com.example.architectureproject;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Accordion;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.Cursor;
import javafx.stage.Stage;

public class BasePage extends Application {




    @Override
    public void start(Stage primaryStage) {
        AnchorPane root = new AnchorPane();
        root.setMaxHeight(Double.NEGATIVE_INFINITY);
        root.setMaxWidth(Double.NEGATIVE_INFINITY);
        root.setMinHeight(Double.NEGATIVE_INFINITY);
        root.setMinWidth(Double.NEGATIVE_INFINITY);
        root.setPrefHeight(675.0);
        root.setPrefWidth(1029.0);
        root.setStyle("-fx-background-color: #F0FFFF;");

        AnchorPane leftPane = new AnchorPane();
        leftPane.setLayoutX(-6.0);
        leftPane.setPrefHeight(675.0);
        leftPane.setPrefWidth(86.0);
        leftPane.setStyle("-fx-background-color: #1e1e2c;");
        ImageView adam = new ImageView(new Image("C:\\Users\\User\\IdeaProjects\\ArchitectureProject\\Files\\icons8-пользователь-мужчина-в-кружке-50.png"));
        adam.setLayoutX(26.0);
        adam.setLayoutY(65.0);
        adam.prefWidth(30.0);
        adam.prefHeight(30.0);
        adam.setOpacity(0.34);

        ImageView calendar = new ImageView(new Image("C:\\Users\\User\\IdeaProjects\\ArchitectureProject\\Files\\icons8-календарь-50.png"));
        calendar.setLayoutX(26.0);
        calendar.setLayoutY(143.0);
        calendar.prefHeight(30.0);
        calendar.prefWidth(30.0);
        calendar.setOpacity(0.34);

        ImageView books = new ImageView(new Image("C:\\Users\\User\\IdeaProjects\\ArchitectureProject\\Files\\icons8-книги-50 (1).png"));
        books.setLayoutX(26.0);
        books.setLayoutY(214.0);
        books.prefWidth(30.0);
        books.prefHeight(30.0);
        books.setOpacity(0.34);

        ImageView outing = new ImageView(new Image("C:\\Users\\User\\IdeaProjects\\ArchitectureProject\\Files\\icons8-выход-50.png"));
        outing.setLayoutX(26.0);
        outing.setLayoutY(610.0);
        outing.prefWidth(30.0);
        outing.prefHeight(30.0);
        outing.setOpacity(0.34);

        Button button1 = createButton(26.0, 65.0, 38.0, 38.0, 0.0);
        button1.setCursor(Cursor.HAND);

        Button button2 = createButton(26.0, 143.0, 38.0, 31.0, 0.0);
        button2.setCursor(Cursor.HAND);

        Button button3 = createButton(26.0, 214.0, 38.0, 31.0, 0.0);
        button3.setText("Button");
        button3.setCursor(Cursor.HAND);

        Button button4 = createButton(26.0, 610.0, 38.0, 31.0, 0.0);
        button4.setCursor(Cursor.HAND);

        leftPane.getChildren().addAll(button1, button2, button3, button4, adam, calendar, books, outing );

        button1.setOnAction(event -> {
            Stage currentStage = (Stage) button1.getScene().getWindow();
            currentStage.close();

            Profile profile = new Profile(currentStage);
            Stage profilestage = new Stage();
            profile.start(profilestage);
        });

        button2.setOnAction(event -> {
            Stage currentStage = (Stage) button2.getScene().getWindow();
            currentStage.close();

            Calendar calendar1 = new Calendar(currentStage);
            Stage calendarStage = new Stage();
            calendar1.start(calendarStage);
        });

        button3.setOnAction(event -> {
            Stage currentStage = (Stage) button3.getScene().getWindow();
            currentStage.close();

            Courses courses = new Courses(currentStage);
            Stage courseStage = new Stage();
            courses.start(courseStage);
        });
        button4.setOnAction(event -> {
            Stage currentStage = (Stage) button3.getScene().getWindow();
            Outing outing1 = new Outing(currentStage);
            Stage outingStage = new Stage();
            outing1.start(outingStage);
        });



        Accordion accordion = new Accordion();
        accordion.setLayoutX(293.0);
        accordion.setLayoutY(143.0);

        root.getChildren().addAll(leftPane, accordion);

        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private Button createButton(double layoutX, double layoutY, double prefWidth, double prefHeight, double opacity) {
        Button button = new Button();
        button.setLayoutX(layoutX);
        button.setLayoutY(layoutY);
        button.setPrefWidth(prefWidth);
        button.setPrefHeight(prefHeight);
        button.setOpacity(opacity);
        button.setMnemonicParsing(false);
        return button;
    }

    public static void main(String[] args) {
        launch(args);
    }
}
