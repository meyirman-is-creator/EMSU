package com.example.architectureproject;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;

public class PhotoUploadApp extends Application {

    private ImageView imageView = new ImageView();

    @Override
    public void start(Stage primaryStage) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Выберите фото");

        Button uploadButton = new Button("Загрузить фото");
        uploadButton.setOnAction(e -> {
            File selectedFile = fileChooser.showOpenDialog(primaryStage);
            if (selectedFile != null) {
                displayImage(selectedFile);
            }
        });

        VBox root = new VBox(uploadButton, imageView);
        Scene scene = new Scene(root, 400, 300);

        primaryStage.setTitle("Загрузка фото");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void displayImage(File file) {
        Image image = new Image(file.toURI().toString());
        imageView.setImage(image);
    }

    public static void main(String[] args) {
        launch(args);
    }
}
