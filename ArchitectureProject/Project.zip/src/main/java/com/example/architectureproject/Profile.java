package com.example.architectureproject;

import javafx.application.Application;
import javafx.scene.Cursor;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;

public class Profile extends Application {
    private File selectedFile;

    public Profile(Stage currentStage) {
    }

    @Override
    public void start(Stage primaryStage) {
        AnchorPane root = new AnchorPane();

        AnchorPane sidePane = new AnchorPane();
        sidePane.setPrefSize(86, 675);
        sidePane.setStyle("-fx-background-color: #1e1e2c;");

        ImageView calendarIcon = new ImageView(new Image("C:\\Users\\User\\IdeaProjects\\ArchitectureProject\\Files\\icons8-календарь-50.png"));
        calendarIcon.setFitHeight(50);
        calendarIcon.setFitWidth(50);
        calendarIcon.setLayoutX(23);
        calendarIcon.setLayoutY(135);
        calendarIcon.setOpacity(0.34);

        ImageView booksIcon = new ImageView(new Image("C:\\Users\\User\\IdeaProjects\\ArchitectureProject\\Files\\icons8-книги-50 (1).png"));
        booksIcon.setFitHeight(50);
        booksIcon.setFitWidth(50);
        booksIcon.setLayoutX(23);
        booksIcon.setLayoutY(205);
        booksIcon.setOpacity(0.38);

        ImageView userIcon = new ImageView(new Image("C:\\Users\\User\\IdeaProjects\\ArchitectureProject\\Files\\icons8-пользователь-мужчина-в-кружке-50.png"));
        userIcon.setFitHeight(50);
        userIcon.setFitWidth(50);
        userIcon.setLayoutX(23);
        userIcon.setLayoutY(63);
        userIcon.setCursor(Cursor.HAND);

        ImageView exitIcon = new ImageView(new Image("C:\\Users\\User\\IdeaProjects\\ArchitectureProject\\Files\\icons8-выход-50.png"));
        exitIcon.setFitHeight(50);
        exitIcon.setFitWidth(50);
        exitIcon.setLayoutX(23);
        exitIcon.setLayoutY(610);
        exitIcon.setOpacity(0.28);

        Button button1 = new Button();
        button1.setLayoutX(23);
        button1.setLayoutY(82);
        button1.setPrefSize(50, 50);
        button1.setOpacity(0.0);
        button1.setCursor(Cursor.HAND);

        Button button2 = new Button();
        button2.setLayoutX(23);
        button2.setLayoutY(147);
        button2.setPrefSize(50, 50);
        button2.setOpacity(0.0);
        button2.setCursor(Cursor.HAND);

        Button button3 = new Button("Button");
        button3.setLayoutX(23);
        button3.setLayoutY(209);
        button3.setPrefSize(50, 50);
        button3.setOpacity(0.0);
        button3.setCursor(Cursor.HAND);

        Button button4 = new Button();
        button4.setLayoutX(23);
        button4.setLayoutY(610);
        button4.setPrefSize(50, 50);
        button4.setOpacity(0.0);
        button4.setCursor(Cursor.HAND);

        sidePane.getChildren().addAll(calendarIcon, booksIcon, userIcon, exitIcon, button1, button2, button3, button4);

        Accordion accordion = new Accordion();
        accordion.setLayoutX(293);
        accordion.setLayoutY(143);

        Rectangle rectangle1 = new Rectangle(293, 574);
        rectangle1.setArcHeight(10);
        rectangle1.setArcWidth(5);
        rectangle1.setFill(javafx.scene.paint.Color.WHITE);
        rectangle1.setLayoutX(124);
        rectangle1.setLayoutY(88);
        rectangle1.setOpacity(0.25);
        rectangle1.setStroke(javafx.scene.paint.Color.BLACK);
        rectangle1.setStrokeType(javafx.scene.shape.StrokeType.INSIDE);
        rectangle1.setStrokeWidth(3);

        Rectangle rectangle2 = new Rectangle(529, 648);
        rectangle2.setArcHeight(10);
        rectangle2.setArcWidth(5);
        rectangle2.setFill(javafx.scene.paint.Color.WHITE);
        rectangle2.setLayoutX(466);
        rectangle2.setLayoutY(14);
        rectangle2.setOpacity(0.24);
        rectangle2.setStroke(javafx.scene.paint.Color.BLACK);
        rectangle2.setStrokeType(javafx.scene.shape.StrokeType.INSIDE);
        rectangle2.setStrokeWidth(3);

        ImageView avatarImage = new ImageView(new Image("C:\\Users\\User\\IdeaProjects\\ArchitectureProject\\Files\\simple-avatar.png"));
        avatarImage.setFitHeight(123);
        avatarImage.setFitWidth(124);
        avatarImage.setLayoutX(209);
        avatarImage.setLayoutY(109);
        avatarImage.setOpacity(0.68);

        Button addPhotoButton = new Button("Add Photo");
        addPhotoButton.setLayoutX(224);
        addPhotoButton.setLayoutY(241);
        addPhotoButton.setPrefSize(94, 30);
        addPhotoButton.setStyle("-fx-background-color: #D3D3D3;");
        addPhotoButton.setCursor(Cursor.HAND);

        Label lastNameLabel = new Label("Last Name:");
        lastNameLabel.setFont(new Font("System Bold", 18));
        lastNameLabel.setLayoutX(147);
        lastNameLabel.setLayoutY(336);

        Label firstNameLabel = new Label("First Name:");
        firstNameLabel.setFont(new Font("System Bold", 18));
        firstNameLabel.setLayoutX(151);
        firstNameLabel.setLayoutY(292);

        Label idNumberLabel = new Label("Id Number:");
        idNumberLabel.setFont(new Font("System Bold", 18));
        idNumberLabel.setLayoutX(148);
        idNumberLabel.setLayoutY(388);

        Label birthdayLabel = new Label("Birthday:");
        birthdayLabel.setFont(new Font("System Bold", 18));
        birthdayLabel.setLayoutX(148);
        birthdayLabel.setLayoutY(542);

        Label genderLabel = new Label("Gender:");
        genderLabel.setFont(new Font("System Bold", 18));
        genderLabel.setLayoutX(148);
        genderLabel.setLayoutY(439);

        Label statusLabel = new Label("Status:");
        statusLabel.setFont(new Font("System Bold", 18));
        statusLabel.setLayoutX(148);
        statusLabel.setLayoutY(491);

        Label editProfileLabel = new Label("Edit Profile");
        editProfileLabel.setFont(new Font(31));
        editProfileLabel.setLayoutX(507);
        editProfileLabel.setLayoutY(54);

        ImageView editIcon = new ImageView(new Image("C:\\Users\\User\\IdeaProjects\\ArchitectureProject\\Files\\edit.png"));
        editIcon.setFitHeight(64);
        editIcon.setFitWidth(86);
        editIcon.setLayoutX(671);
        editIcon.setLayoutY(45);

        TextField firstNameTextField = new TextField();
        firstNameTextField.setLayoutX(622);
        firstNameTextField.setLayoutY(155);
        firstNameTextField.setPrefSize(226, 31);

        TextField lastNameTextField = new TextField();
        lastNameTextField.setLayoutX(624);
        lastNameTextField.setLayoutY(290);
        lastNameTextField.setPrefSize(226, 31);

        TextField idNumberTextField = new TextField();
        idNumberTextField.setLayoutX(623);
        idNumberTextField.setLayoutY(225);
        idNumberTextField.setPrefSize(226, 31);

        Label firstNameInputLabel = new Label("First Name:");
        firstNameInputLabel.setFont(new Font("System Bold", 18));
        firstNameInputLabel.setLayoutX(507);
        firstNameInputLabel.setLayoutY(157);
        Label lastNameInputLabel = new Label("Last Name:");
        lastNameInputLabel.setFont(new Font("System Bold", 18));
        lastNameInputLabel.setLayoutX(508);
        lastNameInputLabel.setLayoutY(227);

        Label idNumberInputLabel = new Label("Id Number:");
        idNumberInputLabel.setFont(new Font("System Bold", 18));
        idNumberInputLabel.setLayoutX(507);
        idNumberInputLabel.setLayoutY(292);

        RadioButton maleRadioButton = new RadioButton("Male");
        maleRadioButton.setFont(new Font(19));
        maleRadioButton.setLayoutX(626);
        maleRadioButton.setLayoutY(359);

        RadioButton femaleRadioButton = new RadioButton("Female");
        femaleRadioButton.setFont(new Font(19));
        femaleRadioButton.setLayoutX(742);
        femaleRadioButton.setLayoutY(359);

        ToggleGroup genderToggleGroup = new ToggleGroup();
        maleRadioButton.setToggleGroup(genderToggleGroup);
        femaleRadioButton.setToggleGroup(genderToggleGroup);

        Label genderInputLabel = new Label("Gender:");
        genderInputLabel.setFont(new Font("System Bold", 18));
        genderInputLabel.setLayoutX(507);
        genderInputLabel.setLayoutY(360);

        DatePicker birthdayDatePicker = new DatePicker();
        birthdayDatePicker.setLayoutX(625);
        birthdayDatePicker.setLayoutY(431);
        birthdayDatePicker.setPrefSize(226, 31);

        Label birthdayInputLabel = new Label("Birthday:");
        birthdayInputLabel.setFont(new Font("System Bold", 18));
        birthdayInputLabel.setLayoutX(505);
        birthdayInputLabel.setLayoutY(429);

        Button updateButton = new Button("Update");
        updateButton.setFont(new Font("System Bold", 22));
        updateButton.setLayoutX(644);
        updateButton.setLayoutY(562);
        updateButton.setPrefSize(197, 48);
        updateButton.setCursor(Cursor.HAND);

        Rectangle rectangle3 = new Rectangle(293, 64);
        rectangle3.setArcHeight(5);
        rectangle3.setArcWidth(5);
        rectangle3.setFill(javafx.scene.paint.Color.WHITE);
        rectangle3.setLayoutX(124);
        rectangle3.setLayoutY(15);
        rectangle3.setOpacity(0.25);
        rectangle3.setStroke(javafx.scene.paint.Color.BLACK);
        rectangle3.setStrokeType(javafx.scene.shape.StrokeType.INSIDE);
        rectangle3.setStrokeWidth(3);

        Label myProfileLabel = new Label("My Profile");
        myProfileLabel.setFont(new Font(31));
        myProfileLabel.setLayoutX(195);
        myProfileLabel.setLayoutY(24);

        button2.setOnAction(event -> {
            Stage currentStage = (Stage) button2.getScene().getWindow();
            currentStage.close();

            Calendar calendar1 = new Calendar(currentStage);
            Stage calendarStage = new Stage();
            calendar1.start(calendarStage);
        });

        button3.setOnAction(event -> {
            Stage currentStage = (Stage) button3.getScene().getWindow();
            currentStage.close();

            Courses courses = new Courses(currentStage);
            Stage courseStage = new Stage();
            courses.start(courseStage);
        });

        button4.setOnAction(event -> {
            Stage currentStage = (Stage) button3.getScene().getWindow();
            Outing outing1 = new Outing(currentStage);
            Stage outingStage = new Stage();
            outing1.start(outingStage);
        });

        addPhotoButton.setOnAction(event -> {
            FileChooser fileChooser = new FileChooser();
            fileChooser.getExtensionFilters().addAll(
                    new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg", "*.gif")
            );
            selectedFile = fileChooser.showOpenDialog(primaryStage);
            if (selectedFile != null) {
                Image image = new Image(selectedFile.toURI().toString());
                avatarImage.setImage(image);
            }
        });

        root.getChildren().addAll(
                sidePane, accordion, rectangle1, rectangle2, avatarImage, addPhotoButton,
                lastNameLabel, firstNameLabel, idNumberLabel, birthdayLabel, genderLabel, statusLabel,
                editProfileLabel, editIcon, firstNameTextField, lastNameTextField, idNumberTextField,
                firstNameInputLabel, lastNameInputLabel, idNumberInputLabel,
                maleRadioButton, femaleRadioButton, genderInputLabel,
                birthdayDatePicker, birthdayInputLabel, updateButton, rectangle3, myProfileLabel
        );

        Scene scene = new Scene(root, 1029, 675);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Your JavaFX Application");
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}


