package com.example.architectureproject;

import javafx.application.Application;
import javafx.scene.Cursor;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.List;

public class RegistrationApp extends Application {
    public List<String> firsttname = new ArrayList<>();
    public List<String> surname = new ArrayList<>();
    public List<String> idnum = new ArrayList<>();
    public List<String> passswordd = new ArrayList<>();
    public List<String> againpassword = new ArrayList<>();
    public List<String> birthDate = new ArrayList<>();
    public List<String> genderr = new ArrayList<>();
    public List<String> studorTeach = new ArrayList<>();
    public RegistrationApp(Stage currentStage) {
    }

    public RegistrationApp() {
    this.idnum = new ArrayList<>();
    this.passswordd = new ArrayList<>();
    }

    private static class UserData {
        String firstName;
        String lastName;
        String idNumber;
        String password;
        String birthday;
        String gender;
        String userType;
    }

    private final UserData userData = new UserData();

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Registration");

        AnchorPane root = new AnchorPane();
        root.setPrefSize(1029, 675);

        ImageView background = new ImageView(new Image("C:\\Users\\User\\IdeaProjects\\ArchitectureProject\\Files\\MainPhoto.jpeg"));
        background.setFitWidth(1038);
        background.setFitHeight(702);

        AnchorPane registrationPane = new AnchorPane();
        registrationPane.setLayoutX(275);
        registrationPane.setLayoutY(81);
        registrationPane.setOpacity(0.89);
        registrationPane.setPrefSize(527, 514);
        registrationPane.setStyle("-fx-background-color: white;");

        Label signUpLabel = new Label("Sign Up");
        signUpLabel.setLayoutX(197);
        signUpLabel.setLayoutY(14);
        signUpLabel.setPrefSize(134, 51);
        signUpLabel.setFont(Font.font("System Bold", 35));

        TextField firstNameField = new TextField();
        setupTextField(firstNameField, "First Name", 126, 99);

        TextField lastNameField = new TextField();
        setupTextField(lastNameField, "Last Name", 125, 150);

        TextField idNumberField = new TextField();
        setupTextField(idNumberField, "ID Number", 125, 205);

        PasswordField passwordField = new PasswordField();
        setupPasswordField(passwordField, "Password", 124, 257);

        PasswordField confirmPasswordField = new PasswordField();
        setupPasswordField(confirmPasswordField, "Password Again", 125, 310);

        DatePicker birthdayDatePicker = new DatePicker();
        birthdayDatePicker.setLayoutX(20);
        birthdayDatePicker.setLayoutY(392);
        birthdayDatePicker.setPrefSize(177, 31);
        birthdayDatePicker.setPromptText("Birthday");
        birthdayDatePicker.setStyle("-fx-background-color: #696969;");

        ToggleGroup genderToggleGroup = new ToggleGroup();

        RadioButton maleRadioButton = new RadioButton("Male");
        setupRadioButton(maleRadioButton, genderToggleGroup, 217, 367);

        RadioButton femaleRadioButton = new RadioButton("Female");
        setupRadioButton(femaleRadioButton, genderToggleGroup, 291, 367);

        ToggleGroup typeToggleGroup = new ToggleGroup();

        RadioButton studentRadioButton = new RadioButton("Student");
        setupRadioButton(studentRadioButton, typeToggleGroup, 217, 410);

        RadioButton teacherRadioButton = new RadioButton("Teacher");
        setupRadioButton(teacherRadioButton, typeToggleGroup, 307, 410);

        Button signInButton = new Button("Sign Up");
        signInButton.setLayoutX(197);
        signInButton.setLayoutY(455);
        signInButton.setPrefSize(134, 45);
        signInButton.setStyle("-fx-background-radius: 25; -fx-border-image-width: 0;");
        signInButton.setTextFill(javafx.scene.paint.Color.web("#5e5e5e"));
        signInButton.setFont(Font.font("System Bold", 20));
        signInButton.setCursor(Cursor.HAND);

        Button exit = new Button("Sign In");
        exit.setLayoutX(0);
        exit.setLayoutY(0);
        exit.setPrefSize(80, 31);
        exit.setStyle("-fx-background-radius: 25; -fx-border-image-width: 0;");
        exit.setTextFill(javafx.scene.paint.Color.web("#5e5e5e"));
        exit.setFont(Font.font("Bold", 15));
        exit.setCursor(Cursor.HAND);


        signInButton.setOnAction(event -> signUpButtonAction(firstNameField, lastNameField, idNumberField,
                passwordField, confirmPasswordField, birthdayDatePicker, maleRadioButton, femaleRadioButton,
                studentRadioButton, teacherRadioButton, exit));

        registrationPane.getChildren().addAll(signUpLabel, firstNameField, lastNameField, idNumberField,
                passwordField, confirmPasswordField, birthdayDatePicker, maleRadioButton, femaleRadioButton,
                studentRadioButton, teacherRadioButton, exit, signInButton);

        exit.setOnAction(event -> {
            Stage currentStage = (Stage) exit.getScene().getWindow();
            currentStage.close();

            SignInSignUpApp signInSignUpApp = new SignInSignUpApp();
            Stage signInStage = new Stage();
            signInSignUpApp.start(signInStage);
        });


        root.getChildren().addAll(background, registrationPane);

        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void setupTextField(TextField textField, String promptText, double layoutX, double layoutY) {
        textField.setLayoutX(layoutX);
        textField.setLayoutY(layoutY);
        textField.setPrefSize(279, 36);
        textField.setPromptText(promptText);
        textField.setStyle("-fx-background-radius: 15;");
    }

    private void setupPasswordField(PasswordField passwordField, String promptText, double layoutX, double layoutY) {
        setupTextField(passwordField, promptText, layoutX, layoutY);
    }

    private void setupRadioButton(RadioButton radioButton, ToggleGroup toggleGroup, double layoutX, double layoutY) {
        radioButton.setLayoutX(layoutX);
        radioButton.setLayoutY(layoutY);
        radioButton.setMnemonicParsing(false);
        radioButton.setToggleGroup(toggleGroup);
        radioButton.setFont(Font.font(16));
        radioButton.setCursor(Cursor.HAND);
    }

    private boolean showError = true;

    private void signUpButtonAction(TextField firstNameField, TextField lastNameField, TextField idNumberField,
                                    PasswordField passwordField, PasswordField confirmPasswordField,
                                    DatePicker birthdayDatePicker, RadioButton maleRadioButton, RadioButton femaleRadioButton,
                                    RadioButton studentRadioButton, RadioButton teacherRadioButton, Button exit) {
        String firstName = firstNameField.getText();
        String lastName = lastNameField.getText();
        String idNumber = idNumberField.getText();
        String password = passwordField.getText();
        String confirmPassword = confirmPasswordField.getText();
        String birthday = (birthdayDatePicker.getValue() != null) ? birthdayDatePicker.getValue().toString() : null;
        String gender = (maleRadioButton.isSelected() || femaleRadioButton.isSelected()) ?
                (maleRadioButton.isSelected() ? "Male" : "Female") : null;
        String userType = (studentRadioButton.isSelected() || teacherRadioButton.isSelected()) ?
                (studentRadioButton.isSelected() ? "Student" : "Teacher") : null;

        if (firstName.isEmpty() || lastName.isEmpty() || idNumber.isEmpty() || password.isEmpty()
                || confirmPassword.isEmpty() || birthday == null || gender == null || userType == null) {
            showErrorDialog("Incomplete Information", "Please fill in all the required fields.");
            return;
        }

        if (password.length() < 8 || confirmPassword.length() < 8) {
            showErrorDialog("Password Length", "Please make sure that password length is not less than 8.");
            return;
        }

        if (!password.equals(confirmPassword)) {
            showErrorDialog("Password Mismatch", "Please make sure the passwords match.");
            return;
        }

        firsttname.add(firstName);
        surname.add(lastName);


        idnum.add(idNumber);
        passswordd.add(password);
        againpassword.add(confirmPassword);
        birthDate.add(birthday);
        genderr.add(gender);
        studorTeach.add(userType);

        showRightDialog("Registration Successful", "You're registered successfully!");

        showError = false;
    }

    private void showErrorDialog(String title, String message) {
        if (showError) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle(title);
            alert.setHeaderText(null);
            alert.setContentText(message);
            alert.showAndWait();
        }
    }

    private void showRightDialog(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

}