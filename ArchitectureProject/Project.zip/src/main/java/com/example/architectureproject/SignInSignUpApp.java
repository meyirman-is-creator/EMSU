package com.example.architectureproject;

import javafx.application.Application;
import javafx.css.Size;
import javafx.css.Style;
import javafx.scene.Cursor;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.util.ArrayList;

public class SignInSignUpApp extends Application {
    private ArrayList<User> userList = new ArrayList<>();

    public SignInSignUpApp() {
    }

    public SignInSignUpApp(Stage currentStage) {
    }

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Sign In/Sign Up");

        AnchorPane root = new AnchorPane();
        root.setPrefSize(1029, 675);

        ImageView background = new ImageView(new Image("C:\\Users\\User\\IdeaProjects\\ArchitectureProject\\Files\\MainPhoto.jpeg"));
        background.setFitWidth(1038);
        background.setFitHeight(702);

        AnchorPane signUpPane = new AnchorPane();
        signUpPane.setLayoutX(512);
        signUpPane.setLayoutY(128);
        signUpPane.setOpacity(0.82);
        signUpPane.setPrefSize(486, 404);
        signUpPane.setStyle("-fx-background-color: #D3D3D3; -fx-background-radius: 5px;");

        Button signUpButton = new Button("Sign Up");
        signUpButton.setLayoutX(206);
        signUpButton.setLayoutY(307);
        signUpButton.setPrefSize(108, 29);
        signUpButton.setStyle("-fx-background-radius: 25; -fx-border-image-width: 40;");
        signUpButton.setTextFill(javafx.scene.paint.Color.web("#5e5e5e"));
        signUpButton.setFont(Font.font("System Bold", 20));
        signUpButton.setCursor(Cursor.HAND);

        Label signUpLabel = new Label("Sign Up");
        signUpLabel.setLayoutX(193);
        signUpLabel.setLayoutY(65);
        signUpLabel.setPrefSize(134, 51);
        signUpLabel.setFont(Font.font("System Bold", 35));
        signUpLabel.setTextFill(javafx.scene.paint.Color.web("#65645f"));

        Text signUpText = new Text("If you do not have an account, please register. Click on the button below");
        signUpText.setLayoutX(54);
        signUpText.setLayoutY(164);
        signUpText.setWrappingWidth(378);
        signUpText.setFont(Font.font("System Bold", 20));
        signUpText.setFill(javafx.scene.paint.Color.web("#393838"));

        signUpPane.getChildren().addAll(signUpButton, signUpLabel, signUpText);

        AnchorPane signInPane = new AnchorPane();
        signInPane.setLayoutX(29);
        signInPane.setLayoutY(97);
        signInPane.setPrefSize(486, 465);
        signInPane.setStyle("-fx-background-color: white;");

        Button signInButton = new Button("Sign In");
        signInButton.setLayoutX(176);
        signInButton.setLayoutY(329);
        signInButton.setPrefSize(134, 45);
        signInButton.setStyle("-fx-background-radius: 25; -fx-border-image-width: 0;");
        signInButton.setTextFill(javafx.scene.paint.Color.web("#5e5e5e"));
        signInButton.setFont(Font.font("System Bold", 20));
        signInButton.setCursor(Cursor.HAND);

        Label signInLabel = new Label("Sign In ");
        signInLabel.setLayoutX(176);
        signInLabel.setLayoutY(63);
        signInLabel.setPrefSize(134, 51);
        signInLabel.setFont(Font.font("System Bold", 35));
        signInLabel.setTextFill(javafx.scene.paint.Color.web("#757575"));

        TextField idNumberField = new TextField();
        setupTextField(idNumberField, "ID Number", 96, 161);

        PasswordField passwordField = new PasswordField();
        setupTextField(passwordField, "Password", 96, 233);

        Hyperlink forgotPasswordLink = new Hyperlink("Forgot Your Password?");
        forgotPasswordLink.setLayoutX(157);
        forgotPasswordLink.setLayoutY(400);
        forgotPasswordLink.setPrefSize(172, 36);


        signUpButton.setOnAction(event -> {
            Stage currentStage = (Stage) signUpButton.getScene().getWindow();
            currentStage.close();

            RegistrationApp registrationApp = new RegistrationApp(currentStage);
            Stage registrationStage = new Stage();
            registrationApp.start(registrationStage);
        });
        Label errorPassword = new Label();
        errorPassword.setText("Password or ID Number is not correct");
        errorPassword.setVisible(false);
        errorPassword.setTextFill(Color.RED);
        errorPassword.setLayoutX(150);
        errorPassword.setLayoutY(380);

        signInButton.setOnAction(event -> {
            String userId = idNumberField.getText();
            String password = passwordField.getText();
            RegistrationApp registrationApp = new RegistrationApp();
            if (registrationApp.idnum.contains(userId) && registrationApp.passswordd.contains(password)){
                Stage currentStage = (Stage) signInButton.getScene().getWindow();
                currentStage.close();


            }
            else{
                errorPassword.setVisible(true);
            }
        });

        signInPane.getChildren().addAll(signInButton, signInLabel, idNumberField, passwordField, forgotPasswordLink);

        root.getChildren().addAll(background, signUpPane, signInPane, errorPassword);

        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    private boolean validateUser(String userId, String password) {
        for (User user : userList) {
            if (user.getUserId().equals(userId) && user.getPassword().equals(password)) {
                return true;
            }
        }
        return false;
    }

    private void setupTextField(TextField textField, String promptText, double layoutX, double layoutY) {
        textField.setLayoutX(layoutX);
        textField.setLayoutY(layoutY);
        textField.setPrefSize(279, 36);
        textField.setPromptText(promptText);
        textField.setStyle("-fx-background-radius: 15;");

    }

}
