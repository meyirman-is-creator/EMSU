module com.example.architectureproject {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.architectureproject to javafx.fxml;
    exports com.example.architectureproject;
}